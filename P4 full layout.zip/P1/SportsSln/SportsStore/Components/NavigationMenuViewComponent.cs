﻿namespace SportsStore.Components
{
    public class NavigationMenuViewComponent
    {
    }
}
