﻿namespace SportsStore.Models
{
    public class Product
    {
    }
}
