﻿namespace SportsStore.Models
{
    public class SeedData
    {
    }
}
