﻿namespace SportsStore.Models
{
    public class EFStoreRepository
    {
    }
}
