﻿namespace SportsStore.Models.ViewModels
{
    public class PagingInfo
    {
    }
}
