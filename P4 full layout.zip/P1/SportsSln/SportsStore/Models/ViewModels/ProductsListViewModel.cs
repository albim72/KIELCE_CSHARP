﻿namespace SportsStore.Models.ViewModels
{
    public class ProductsListViewModel
    {
    }
}
