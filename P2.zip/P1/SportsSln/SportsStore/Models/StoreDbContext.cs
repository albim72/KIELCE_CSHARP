﻿namespace SportsStore.Models
{
    public class StoreDbContext
    {
    }
}
