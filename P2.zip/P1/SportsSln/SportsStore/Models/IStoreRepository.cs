﻿namespace SportsStore.Models
{
    public interface IStoreRepository
    {
    }
}
