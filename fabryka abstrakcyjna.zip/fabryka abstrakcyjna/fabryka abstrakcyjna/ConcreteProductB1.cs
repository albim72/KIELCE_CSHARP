﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fabryka_abstrakcyjna
{
    public class ConcreteProductB1 : IAbstractProductB
    {
        public string AnotherUsefulFunctionB(IAbstractProductA collaborator)
        {
            var result = collaborator.UsefulFunctionA();
            return $"wynik współpracy B1 z {result}";
        }

        public string UsefulFunctionB()
        {
            return "wynik tworzenia produktu B1";
        }
    }
}
