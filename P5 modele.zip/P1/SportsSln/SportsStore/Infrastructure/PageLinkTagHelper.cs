﻿namespace SportsStore.Infrastructure
{
    public class PageLinkTagHelper
    {
    }
}
