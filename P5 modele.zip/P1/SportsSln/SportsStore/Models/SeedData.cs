﻿using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace SportsStore.Models
{
    public class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            StoreDbContext context = 
                app.ApplicationServices.CreateScope().ServiceProvider.GetRequiredService<StoreDbContext>();
            if (context.Database.GetPendingMigrations().Any())
            {
                context.Database.Migrate();
            }

            if (!context.Products.Any())
            {
                context.Products.AddRange(
                    new Product
                    {
                        Name = "Kajak",
                        Description = "Kajka dwuosobowy z opcją bagażu....",
                        Category = "Sporty wodne",
                        Price = 1280
                    },
                    new Product
                    {
                        Name = "Kamizelka ratunkowa",
                        Description = "Ochrona przed utonięciem....",
                        Category = "Sporty wodne",
                        Price = 111.22m
                    },
                    new Product
                    {
                        Name = "Piłka do gry w football",
                        Description = "Piłka FIFA 2022",
                        Category = "Piłka nożna",
                        Price = 38.77m
                    },
                    new Product
                    {
                        Name = "Flaga narodowa",
                        Description = "Coś dla kibica....",
                        Category = "Piłka nożna",
                        Price = 35.18m
                    },
                    new Product
                    {
                        Name = "Stadion",
                        Description = "składany stadion na 35000 osób",
                        Category = "Piłka nożna",
                        Price = 2340888
                    },
                    new Product
                    {
                        Name = "Czapka",
                        Description = "większa efektywność mózgu o 76%",
                        Category = "Szachy",
                        Price = 88
                    },
                    new Product
                    {
                        Name = "Niestabilne krzesło",
                        Description = "zmniejsza szanse przeciwnika",
                        Category = "Szachy",
                        Price = 212.55m
                    },
                    
                    new Product
                    {
                        Name = "Ludzka szachownica",
                        Description = "Gra dla rodziny i znajomych",
                        Category = "szachy",
                        Price = 555
                    },
                    new Product
                    {
                        Name = "Piłka do gry w football",
                        Description = "Piłka FIFA 2022",
                        Category = "Piłka nożna",
                        Price = 38.77m
                    },
                    new Product
                    {
                        Name = "Błyszczący Król",
                        Description = "Figura pokryta złotem...",
                        Category = "Szachy",
                        Price = 12600
                    }


                    );
                context.SaveChanges();
            }
        }
    }
}
