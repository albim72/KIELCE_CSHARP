using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsStore.Views.Shared.Components.NavigationMenu
{
    public class DefaultModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
