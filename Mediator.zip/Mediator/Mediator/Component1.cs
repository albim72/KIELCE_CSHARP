﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediator
{
    class Component1:BaseComponent
    {
        public void DoA()
        {
            Console.WriteLine("Komponent pierwszy posiada A");
            this._mediator.Notify(this, "A");

        }
        public void DoB()
        {
            Console.WriteLine("Komponent pierwszy posiada B");
            this._mediator.Notify(this, "B");

        }
    }
}
