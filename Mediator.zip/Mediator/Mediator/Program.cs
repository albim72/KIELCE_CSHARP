﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Component1 component1 = new Component1();
            Component2 component2 = new Component2();

            new ConcreteMediator(component1, component2);
            Console.WriteLine("Operacje na kliencie A");
            component1.DoA();
            Console.WriteLine();
            Console.WriteLine("Operacje na kliencie D");
            component2.DoD();
            Console.WriteLine();

            Console.ReadKey();

        }
    }
}
