﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediator
{ 

    class Component2:BaseComponent
    {
        public void DoC()
        {
            Console.WriteLine("Komponent drugi posiada C");
            this._mediator.Notify(this, "C");

        }
        public void DoD()
        {
            Console.WriteLine("Komponent drugi posiada D");
            this._mediator.Notify(this, "D");

        }
    }
}
