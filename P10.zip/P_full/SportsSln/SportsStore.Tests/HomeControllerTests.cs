﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;
using SportsStore.Controllers;
using SportsStore.Models;
using SportsStore.Models.ViewModels;


namespace SportsStore.Tests
{
    public class HomeControllerTests
    {
        [Fact]
        public void Can_UseRepository()
        {
            //Przygotowanie
            Mock<IStoreRepository> mock = new Mock<IStoreRepository>();
            mock.Setup(m => m.Products).Returns((new Product[] {
            new Product{ProductID=1,Name="P1"},
            new Product{ProductID=2,Name="P2"}
            }
            ).AsQueryable<Product>());

            HomeController controller = new HomeController(mock.Object);

            //Działanie
            ProductsListViewModel result = controller.Index(null).ViewData.Model as ProductsListViewModel;

            //
            Product[] prodArray = result.Products.ToArray();
            Assert.True(prodArray.Length==2);
            Assert.Equal("P1",prodArray[0].Name);
            Assert.Equal("P2",prodArray[1].Name);
        }
    }
}
