﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prototyp
{
    internal class Program
    {
        public static void DisplayValues(Person p)
        {
            Console.WriteLine($"   Imię:{p.Name:s}, Wiek: {p.Age:d}, Data urodzenia: {p.BirthDate:MM/dd/yy}");
            Console.WriteLine($"   ID#: {p.IdInfo.IdNumber:d}");
        }
        static void Main(string[] args)
        {
            Person p1 = new Person();
            p1.Age = 45;
            p1.BirthDate = Convert.ToDateTime("1977-01-20");
            p1.Name = "Jan Kowalski";
            p1.IdInfo = new IdInfo(122);

            Person p2 = p1.ShallowCopy();
            Person p3 = p1.DeepCopy();

            Console.WriteLine("Oryginalne wartości: p1,p2,p3: ");
            Console.WriteLine($"Wartość p1:");
            DisplayValues(p1);
            Console.WriteLine($"Wartość p2:");
            DisplayValues(p2);
            Console.WriteLine($"Wartość p3:");
            DisplayValues(p3);

            p1.Age = 32;
            p1.BirthDate = Convert.ToDateTime("1980-01-20");
            p1.Name = "Franek Kimono";
            p1.IdInfo.IdNumber = 78787;

            Console.WriteLine("\n wartości: p1,p2,p3 po zmianie p1... ");
            Console.WriteLine($"Wartość p1:");
            DisplayValues(p1);
            Console.WriteLine($"Wartość p2:");
            DisplayValues(p2);
            Console.WriteLine($"Wartość p3:");
            DisplayValues(p3);

            Console.ReadKey();

        }
    }
}
