﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adapter
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Adaptation adp = new Adaptation();
            ITarget target = new Adapter(adp);

            Console.WriteLine("Interfejs Adaptation jest niekomatybilny z klientem");
            Console.WriteLine("....ale, za pomocą adaptera klienta może wywołać właściwą metodę....");

            Console.WriteLine(target.GetRequest());

            Console.ReadKey();
        }
    }
}
