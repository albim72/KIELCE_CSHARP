﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace budowniczy
{
    public class ConcreteBuilder : IBuilder
    {
        private Product _product = new Product();
       
        public ConcreteBuilder()
        {
            this.Reset();
        }
        public void Reset()
        {
            this._product = new Product();
        }

        public void BuiltPartA()
        {
            this._product.Add("część A1");
        }
        public void BuiltPartB()
        {
            this._product.Add("część B1");
        }

        public void BuiltPartC()
        {
            this._product.Add("część C1");
        }

        public Product GetProduct()
        {
            Product result = this._product;
            this.Reset();
            return result;
        }
    }
}
