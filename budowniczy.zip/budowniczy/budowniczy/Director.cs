﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace budowniczy
{
    public class Director
    {
        private IBuilder _builder;
        public IBuilder Builder
        {
            set { _builder = value; }
        }
        public void BuildMinimalVariableProduct()
        {
            this._builder.BuiltPartA();
        }
        public void BuildFullFeatureProduct()
        {
            this._builder.BuiltPartA();
            this._builder.BuiltPartB();
            this._builder.BuiltPartC();
        }
    }
}
