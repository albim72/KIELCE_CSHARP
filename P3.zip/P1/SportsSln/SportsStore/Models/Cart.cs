﻿namespace SportsStore.Models
{
    public class Cart
    {
    }
}
