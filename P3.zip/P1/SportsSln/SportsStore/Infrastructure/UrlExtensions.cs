﻿namespace SportsStore.Infrastructure
{
    public class UrlExtensions
    {
    }
}
