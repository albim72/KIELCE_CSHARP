﻿namespace SportsStore.Infrastructure
{
    public class SessionExtensions
    {
    }
}
