﻿
namespace zadanie_wstepne_KLUB
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbStandard = new System.Windows.Forms.RadioButton();
            this.rbGold = new System.Windows.Forms.RadioButton();
            this.rbVIP = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rb3lata = new System.Windows.Forms.RadioButton();
            this.rb2lata = new System.Windows.Forms.RadioButton();
            this.rb1rok = new System.Windows.Forms.RadioButton();
            this.cbMiasto = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnRejestracja = new System.Windows.Forms.Button();
            this.tbImie = new System.Windows.Forms.TextBox();
            this.tbNazwisko = new System.Windows.Forms.TextBox();
            this.tbOsoba = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbZaplata = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(45, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(274, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "CZŁONKOWSTWO - REJESTRACJA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(45, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(308, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Klub sympatyków języka C#";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(45, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "imię";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(45, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "nazwisko";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 13);
            this.label5.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbStandard);
            this.groupBox1.Controls.Add(this.rbGold);
            this.groupBox1.Controls.Add(this.rbVIP);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox1.Location = new System.Drawing.Point(48, 222);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 112);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "rodzaj czlonkowstwa";
            // 
            // rbStandard
            // 
            this.rbStandard.AutoSize = true;
            this.rbStandard.Location = new System.Drawing.Point(7, 76);
            this.rbStandard.Name = "rbStandard";
            this.rbStandard.Size = new System.Drawing.Size(90, 24);
            this.rbStandard.TabIndex = 2;
            this.rbStandard.TabStop = true;
            this.rbStandard.Text = "standard";
            this.rbStandard.UseVisualStyleBackColor = true;
            this.rbStandard.CheckedChanged += new System.EventHandler(this.rbStandard_CheckedChanged);
            // 
            // rbGold
            // 
            this.rbGold.AutoSize = true;
            this.rbGold.Location = new System.Drawing.Point(7, 48);
            this.rbGold.Name = "rbGold";
            this.rbGold.Size = new System.Drawing.Size(61, 24);
            this.rbGold.TabIndex = 1;
            this.rbGold.TabStop = true;
            this.rbGold.Text = "Gold";
            this.rbGold.UseVisualStyleBackColor = true;
            this.rbGold.CheckedChanged += new System.EventHandler(this.rbGold_CheckedChanged);
            // 
            // rbVIP
            // 
            this.rbVIP.AutoSize = true;
            this.rbVIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rbVIP.Location = new System.Drawing.Point(7, 20);
            this.rbVIP.Name = "rbVIP";
            this.rbVIP.Size = new System.Drawing.Size(53, 24);
            this.rbVIP.TabIndex = 0;
            this.rbVIP.TabStop = true;
            this.rbVIP.Text = "VIP";
            this.rbVIP.UseVisualStyleBackColor = true;
            this.rbVIP.CheckedChanged += new System.EventHandler(this.rbVIP_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rb3lata);
            this.groupBox2.Controls.Add(this.rb2lata);
            this.groupBox2.Controls.Add(this.rb1rok);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox2.Location = new System.Drawing.Point(327, 222);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 112);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "czas trwania";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // rb3lata
            // 
            this.rb3lata.AutoSize = true;
            this.rb3lata.Location = new System.Drawing.Point(7, 76);
            this.rb3lata.Name = "rb3lata";
            this.rb3lata.Size = new System.Drawing.Size(66, 24);
            this.rb3lata.TabIndex = 2;
            this.rb3lata.TabStop = true;
            this.rb3lata.Text = "3 lata";
            this.rb3lata.UseVisualStyleBackColor = true;
            this.rb3lata.CheckedChanged += new System.EventHandler(this.rb3lata_CheckedChanged);
            // 
            // rb2lata
            // 
            this.rb2lata.AutoSize = true;
            this.rb2lata.Location = new System.Drawing.Point(7, 48);
            this.rb2lata.Name = "rb2lata";
            this.rb2lata.Size = new System.Drawing.Size(66, 24);
            this.rb2lata.TabIndex = 1;
            this.rb2lata.TabStop = true;
            this.rb2lata.Text = "2 lata";
            this.rb2lata.UseVisualStyleBackColor = true;
            this.rb2lata.CheckedChanged += new System.EventHandler(this.rb2lata_CheckedChanged);
            // 
            // rb1rok
            // 
            this.rb1rok.AutoSize = true;
            this.rb1rok.Location = new System.Drawing.Point(7, 20);
            this.rb1rok.Name = "rb1rok";
            this.rb1rok.Size = new System.Drawing.Size(62, 24);
            this.rb1rok.TabIndex = 0;
            this.rb1rok.TabStop = true;
            this.rb1rok.Text = "1 rok";
            this.rb1rok.UseVisualStyleBackColor = true;
            this.rb1rok.CheckedChanged += new System.EventHandler(this.rb1rok_CheckedChanged);
            // 
            // cbMiasto
            // 
            this.cbMiasto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cbMiasto.FormattingEnabled = true;
            this.cbMiasto.Items.AddRange(new object[] {
            "Kraków",
            "Lublin",
            "Warszawa",
            "Gdańsk",
            "Katowice",
            "Toruń"});
            this.cbMiasto.Location = new System.Drawing.Point(158, 172);
            this.cbMiasto.Name = "cbMiasto";
            this.cbMiasto.Size = new System.Drawing.Size(261, 28);
            this.cbMiasto.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(48, 172);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "miasto";
            // 
            // btnRejestracja
            // 
            this.btnRejestracja.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnRejestracja.Location = new System.Drawing.Point(51, 351);
            this.btnRejestracja.Name = "btnRejestracja";
            this.btnRejestracja.Size = new System.Drawing.Size(476, 36);
            this.btnRejestracja.TabIndex = 9;
            this.btnRejestracja.Text = "ZAREJESTRUJ";
            this.btnRejestracja.UseVisualStyleBackColor = true;
            this.btnRejestracja.Click += new System.EventHandler(this.btnRejestracja_Click);
            // 
            // tbImie
            // 
            this.tbImie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbImie.Location = new System.Drawing.Point(158, 90);
            this.tbImie.Name = "tbImie";
            this.tbImie.Size = new System.Drawing.Size(261, 26);
            this.tbImie.TabIndex = 10;
            // 
            // tbNazwisko
            // 
            this.tbNazwisko.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbNazwisko.Location = new System.Drawing.Point(158, 134);
            this.tbNazwisko.Name = "tbNazwisko";
            this.tbNazwisko.Size = new System.Drawing.Size(261, 26);
            this.tbNazwisko.TabIndex = 11;
            // 
            // tbOsoba
            // 
            this.tbOsoba.Enabled = false;
            this.tbOsoba.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbOsoba.Location = new System.Drawing.Point(48, 412);
            this.tbOsoba.Multiline = true;
            this.tbOsoba.Name = "tbOsoba";
            this.tbOsoba.Size = new System.Drawing.Size(479, 69);
            this.tbOsoba.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(48, 510);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "DO ZAPŁATY";
            // 
            // tbZaplata
            // 
            this.tbZaplata.Enabled = false;
            this.tbZaplata.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbZaplata.Location = new System.Drawing.Point(162, 504);
            this.tbZaplata.Name = "tbZaplata";
            this.tbZaplata.Size = new System.Drawing.Size(369, 26);
            this.tbZaplata.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(619, 627);
            this.Controls.Add(this.tbZaplata);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tbOsoba);
            this.Controls.Add(this.tbNazwisko);
            this.Controls.Add(this.tbImie);
            this.Controls.Add(this.btnRejestracja);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbMiasto);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "KLUB C#";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbStandard;
        private System.Windows.Forms.RadioButton rbGold;
        private System.Windows.Forms.RadioButton rbVIP;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rb3lata;
        private System.Windows.Forms.RadioButton rb2lata;
        private System.Windows.Forms.RadioButton rb1rok;
        private System.Windows.Forms.ComboBox cbMiasto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnRejestracja;
        private System.Windows.Forms.TextBox tbImie;
        private System.Windows.Forms.TextBox tbNazwisko;
        private System.Windows.Forms.TextBox tbOsoba;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbZaplata;
    }
}

