﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_wstepne_KLUB
{

    class Czlonkowstwo : Klubowicz, IKlub
    {
        public string rodzaj_czl;
        public string czas_trw;
        public Czlonkowstwo(string imie, string nazwisko, string miasto, 
            string rodzaj_czl, string czas_trw) : 
            base(imie, nazwisko, miasto)
        {
            this.rodzaj_czl = rodzaj_czl;
            this.czas_trw = czas_trw;
        }

        public string info_o_klubie()
        {
            return "Klub zrzesza programistów języka C#.....";
        }

        public double licz_skladke()
        {

            int std1 = 150;
            int std2 = 280;
            int std3 = 400;
            double zap = 0;
            switch (rodzaj_czl)
            {
                case "vip":
                    switch(czas_trw)
                        {
                        case "1rok":
                            zap = std1 * 1.25;
                            break;
                        case "2lata":
                            zap = std2 * 1.25;
                            break;
                        case "3lata":
                            zap = std3 * 1.25;
                            break;
                    }
                    break;
                case "gold":
                    switch (czas_trw)
                    {
                        case "1rok":
                            zap = std1 * 1.1;
                            break;
                        case "2lata":
                            zap = std2 * 1.1;
                            break;
                        case "3lata":
                            zap = std3 * 1.1;
                            break;
                    }
                    break;
                case "std":
                    switch (czas_trw)
                    {
                        case "1rok":
                            zap = std1;
                            break;
                        case "2lata":
                            zap = std2;
                            break;
                        case "3lata":
                            zap = std3;
                            break;
                    }
                    break;

            }


            return zap;


        }

        public override string opis_osoby()
        {
            return $"Osoba zarejestrowana jako członek klubu - imię: {imie}, nazwisko: {nazwisko}, miasto: {miasto}";
        }
    }
}
