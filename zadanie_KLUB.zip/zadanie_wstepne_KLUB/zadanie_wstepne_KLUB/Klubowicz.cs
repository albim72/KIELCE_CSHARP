﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_wstepne_KLUB
{
    public abstract class Klubowicz
    {
        protected string imie;
        protected string nazwisko;
        protected string miasto;

        protected Klubowicz(string imie, string nazwisko, string miasto)
        {
            this.imie = imie;
            this.nazwisko = nazwisko;
            this.miasto = miasto;
            start();
        }

        public abstract string opis_osoby();

        public void start()
        {
            Console.WriteLine("Członkowstwo w klubie to duże wsparcie dla młodego programisty");
        }
        

    }
}
