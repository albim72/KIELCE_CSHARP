﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zadanie_wstepne_KLUB
{
    
    public partial class Form1 : Form
    {

        public string rodzaj;
        public string czas;
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btnRejestracja_Click(object sender, EventArgs e)
        {
            string imie = tbImie.Text;
            string nazwisko = tbNazwisko.Text;
            string miasto = cbMiasto.Text;
           
            

            Czlonkowstwo cz = new Czlonkowstwo(imie,nazwisko,miasto,rodzaj,czas);

            tbOsoba.Text = cz.opis_osoby().ToString();
            tbZaplata.Text = cz.licz_skladke().ToString();

            MessageBox.Show(cz.info_o_klubie(),"Informacja i klubie");
        }

        private void rbVIP_CheckedChanged(object sender, EventArgs e)
        {
            rodzaj = "vip";
        }

        private void rbGold_CheckedChanged(object sender, EventArgs e)
        {
            rodzaj = "gold";
        }

        private void rbStandard_CheckedChanged(object sender, EventArgs e)
        {
            rodzaj = "std";
        }

        private void rb1rok_CheckedChanged(object sender, EventArgs e)
        {
            czas = "1rok";
        }

        private void rb2lata_CheckedChanged(object sender, EventArgs e)
        {
            czas = "2lata";
        }

        private void rb3lata_CheckedChanged(object sender, EventArgs e)
        {
            czas = "3lata";
        }
    }
}
